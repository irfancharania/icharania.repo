class NetworkError(Exception):
    pass


class NoEpisodesFound(Exception):
    pass