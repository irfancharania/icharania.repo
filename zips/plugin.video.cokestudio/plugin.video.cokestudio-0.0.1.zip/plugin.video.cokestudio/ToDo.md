- Add bookmarks

- Add caching

- Do addon string text in languages