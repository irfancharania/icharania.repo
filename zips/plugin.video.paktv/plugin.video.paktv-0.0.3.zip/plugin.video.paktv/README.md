This is an XBMC Video Plugin for streaming content from ThePakTV forums


To do:

- request exception handling
- add "channels"
- use local images for channels
- store resolver tuple 'enable/disable' in settings (tune, youtube, dailymotion)
    - allow me to disable a particular one if I don't want it
    - e.g. youtube doesn't work for a number of countries

