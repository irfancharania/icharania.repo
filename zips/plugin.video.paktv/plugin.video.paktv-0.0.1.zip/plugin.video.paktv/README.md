This is an XBMC Video Plugin for streaming content from ThePakTV forums


To do:

- cache url requests
- request exception handling
- add more iframe content
- add tunepk resolver
- fix dailymotion resolver
- add page navigation for shows (next page)
- add "channels"
- add category for "Today" iframe (days of week)
